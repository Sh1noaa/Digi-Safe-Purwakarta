<?php

use App\Http\Middleware\AdminMiddleware;
use App\Http\Middleware\ApiAdminMiddleware;
use App\Http\Middleware\ApiTokenAuth;
use App\Http\Middleware\ApiTokenOptional;
use App\Http\Middleware\SetUserPreferences;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->trustProxies(at: '*');
        $middleware->web(append: [
            SetUserPreferences::class,
        ]);
        $middleware->alias([
            'admin' => AdminMiddleware::class,
            'api.optional' => ApiTokenOptional::class,
            'api.auth' => ApiTokenAuth::class,
            'api.admin' => ApiAdminMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
